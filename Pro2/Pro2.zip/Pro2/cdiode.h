/**
* \brief class cdiode inherit from Element
* \details   contain mathods witch allow generate svg code. It's capacity diode and this simbol is generated.
* \author    Tomasz Nowak
*/
#ifndef CDIODE_H
#define CDIODE_H
#include"Element.h"

class cdiode : public Element {

protected:
    ///spin involved amount of degrees. How much capacity diode is rotated.
	unsigned short spin;

public:
    /// This is ID of this class. You can see field is static so every object of this type has the same ID.
    /// This is given by method of factory class.
    static unsigned Type;

    /**
    * \brief default constructor
    * \details
    * width = 100;
    * all interior_color = 100;
    * all local = 100;
    * spin = 0;
    */
    cdiode();
    ///constructor
    cdiode(unsigned short width, unsigned short interior_color[], unsigned short local[], unsigned short spin);//konstrukto
    /// \brief setter for spin
    void set_spin(unsigned short spin){this->spin=spin;}

    /**
    * \brief static function returning pointer to object cdiode.
    * \details Given to object type Factory. It's explaining why this function is static.
    */
    static Element *  Createcdiode(){return new cdiode();}

    /**
    * \brief show ID class cdiode. Returns ID.
    *
    */
    virtual unsigned int show_type(){return Type;}
    /**
    * \brief It's describing specification of object type cdiode in terminal.
    * \details Come from class of Element
    */
    virtual void write();
    /** \brief Exports cdiode to svg.
     * \param file to this file will be exported code svg describing cdiode.
     * \attention file should be opened and extension should be .svg. This method don't close file.
     */
    virtual void draw(std::ofstream &file);
    /** \brief Exports specification of cdiode to file.
     * \param file to this file will be exported all information of cdiode.
     * \attention file should be open, prefered extension is .txt. This method don't close file.
     */
    virtual void save(std::ofstream &file);
    /** \brief Imports specification of cdiode from file.
     * \param file from this will be imported all information of cdiode.
     * \attention file should be open. This method don't close file. */
    virtual void read(std::ifstream &file);
};
#endif
