/**
* \brief class spinspinftransistor inherit from spinftransistor
* \details   contain mathods witch allow generate svg code. It's phototransistor witch can be
* rotated and this simbol is generated.
* \author    Jakub Wieczorek
*/

#ifndef SPINspinftransistor_H
#define SPINspinftransistor_H
#include"ftransistor.h"

class spinftransistor : public ftransistor{
protected:
    ///spin involved amount of degrees. How much element is rotated.
    unsigned short spin;
public:
    /// \brief setter to spin
    void set_spin(unsigned short spin){this->spin=spin;}
    /// This is ID of this class. You can see field is static so every object of this type has the same ID.
    /// This is given by method of factory class.
    static unsigned int Type;
    ///\brief constructor
    spinftransistor(unsigned short width, unsigned short line_color[], unsigned short interior_color[], unsigned short stroke_width, unsigned short local[], std::string name, unsigned short spin);//konstruktor
    /**
    * \brief default constructor
    * \details
    * width = 100
    * all interior_color = 200
    * all local = 200
    * all line color = 100
    * name = spinftransistor
    * stroke_width = 5
    * spin = 0
    */
    spinftransistor();
    /**
    * \brief static function returning pointer to object of spinftransistor type.
    * \details Given to object type Factory. It's explaining why this function is static.
    */
    static Element *  Createspinftransistor(){return new spinftransistor();}
    /**
    * \brief show ID class of spinspinftransistor. Returns ID.
    *
    */
    virtual unsigned int show_type(){return Type;}
    /** \brief Exports spinspinftransistor to svg.
     * \param file to this file will be exported code svg describing ftrasistor.
     * \attention file should be opened and extension should be .svg. This method don't close file.
     */
    virtual void draw(std::ofstream &file);
    /**
    * \brief It's describing specification of object type spinftransistor in terminal.
    * \details Come from class of Element
    */
    virtual void write();
    /** \brief Exports specification of spinftransistor to file.
     * \param file to this file will be exported all information of spinftransistor.
     * \attention file should be open, prefered extension is .txt. This method don't close file.
     */
    virtual void save(std::ofstream &file);
    /** \brief Imports specification of spinftransistor from file.
     * \param file from this will be imported all information of spinftransistor.
     * \attention file should be open. This method don't close file. */
    virtual void read(std::ifstream &file);
};
#endif
