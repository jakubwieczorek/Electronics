var searchData=
[
  ['type',['Type',['../classcdiode.html#a97b6675cd92df600d329bafc20ce51ac',1,'cdiode::Type()'],['../classspinftransistor.html#adcae920a946d5071e6103e02c042c757',1,'spinftransistor::Type()'],['../classftransistor.html#a20a262510c3e52ebb31816c5e150fa8a',1,'ftransistor::Type()']]]
];
