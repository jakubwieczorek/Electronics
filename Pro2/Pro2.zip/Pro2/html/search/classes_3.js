var searchData=
[
  ['ftransistor',['ftransistor',['../classftransistor.html',1,'']]]
];
