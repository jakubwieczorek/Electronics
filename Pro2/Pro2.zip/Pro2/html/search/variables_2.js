var searchData=
[
  ['line_5fcolor',['line_color',['../classLCcdiode.html#a501b3c6a73326a5561773bd80e173f99',1,'LCcdiode::line_color()'],['../classftransistor.html#aab68ab8fd90279d4bf168de81666a003',1,'ftransistor::line_color()']]],
  ['local',['local',['../classElement.html#ab7ec293eb49134a38bd3362cad0955d4',1,'Element']]]
];
