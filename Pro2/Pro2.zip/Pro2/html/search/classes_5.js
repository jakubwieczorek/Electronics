var searchData=
[
  ['spinftransistor',['spinftransistor',['../classspinftransistor.html',1,'']]]
];
