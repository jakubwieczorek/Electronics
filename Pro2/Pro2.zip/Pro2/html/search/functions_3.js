var searchData=
[
  ['lccdiode',['LCcdiode',['../classLCcdiode.html#a20b60508fbcfde5787fa977f2b7e402b',1,'LCcdiode::LCcdiode()'],['../classLCcdiode.html#a03953f4c0a3fda978db5d7ef6a8c0e9b',1,'LCcdiode::LCcdiode(unsigned short width, unsigned short interior_color[], unsigned short local[], unsigned short spin, unsigned short line_color[])']]]
];
