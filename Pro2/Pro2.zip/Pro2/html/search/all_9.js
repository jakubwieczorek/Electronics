var searchData=
[
  ['save',['save',['../classcdiode.html#a92e1f28b7b961c026b7cecba423c8da2',1,'cdiode::save()'],['../classLCcdiode.html#a4767ea0aea73f983675be2a89497c271',1,'LCcdiode::save()'],['../classspinftransistor.html#ab203cbb7b26d7f20ceca3679b71bd463',1,'spinftransistor::save()'],['../classDokument.html#ad4f38703f7da70d1e15823743d88e4da',1,'Dokument::save()'],['../classftransistor.html#a131f0b1b8fc7b57574c243d9f41a9be4',1,'ftransistor::save()'],['../classElement.html#ad1e99d39534c4fef2df125432bbe1b98',1,'Element::save()']]],
  ['set_5finterior_5fcolor',['set_interior_color',['../classElement.html#a1e536e257b966511b8178558cd5edf44',1,'Element']]],
  ['set_5fline_5fcolor',['set_line_color',['../classLCcdiode.html#a8bade03257f0cb48a735c04b5b91d086',1,'LCcdiode::set_line_color()'],['../classftransistor.html#a61765b6156709ffcd752afcffdaefe55',1,'ftransistor::set_line_color()']]],
  ['set_5flocal',['set_local',['../classElement.html#a34d61a3304aae37229992bee8c5e3548',1,'Element']]],
  ['set_5fname',['set_name',['../classftransistor.html#a5ebbecd6d018b2d06a72ff8da1049323',1,'ftransistor']]],
  ['set_5fspin',['set_spin',['../classcdiode.html#a3f938e83df2f51c7500d74969bb0754d',1,'cdiode::set_spin()'],['../classspinftransistor.html#a1e1f6d3e879cba6ffaf3910b68aa81c2',1,'spinftransistor::set_spin()']]],
  ['set_5fstroke_5fwidth',['set_stroke_width',['../classftransistor.html#afe12a56bf9c63505bcec7c5f5cd6f132',1,'ftransistor']]],
  ['set_5fwidth',['set_width',['../classElement.html#acf15a4e357808d91ecf9b54296e5c7c5',1,'Element']]],
  ['show_5ftype',['show_type',['../classcdiode.html#a4a4b34e33377bfaa5f37827f610f1acb',1,'cdiode::show_type()'],['../classLCcdiode.html#a00483b4f6e9fe4c0b60a8ea1fb94b871',1,'LCcdiode::show_type()'],['../classspinftransistor.html#af6f9736a3d04775a87df7248abc847c8',1,'spinftransistor::show_type()'],['../classftransistor.html#aa43206a1d4d09fc939960f4df3fd6dc8',1,'ftransistor::show_type()'],['../classElement.html#a447cd50e274a53e5e7e601a50c0bd20c',1,'Element::show_type()']]],
  ['spin',['spin',['../classcdiode.html#a15fcbbffe942188069a77a2391380088',1,'cdiode::spin()'],['../classspinftransistor.html#a4efea110c352bd12cb76e527eeb35c18',1,'spinftransistor::spin()']]],
  ['spinftransistor',['spinftransistor',['../classspinftransistor.html',1,'spinftransistor'],['../classspinftransistor.html#a1864f88220fcfd099a96efcc155e1e7d',1,'spinftransistor::spinftransistor(unsigned short width, unsigned short line_color[], unsigned short interior_color[], unsigned short stroke_width, unsigned short local[], std::string name, unsigned short spin)'],['../classspinftransistor.html#a693962f585447437f0c8c531942d0bb0',1,'spinftransistor::spinftransistor()']]],
  ['stroke_5fwidth',['stroke_width',['../classftransistor.html#a54583de79c6b0688a5567e2941b7eda4',1,'ftransistor']]]
];
