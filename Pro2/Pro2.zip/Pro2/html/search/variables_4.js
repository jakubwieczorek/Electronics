var searchData=
[
  ['spin',['spin',['../classcdiode.html#a15fcbbffe942188069a77a2391380088',1,'cdiode::spin()'],['../classspinftransistor.html#a4efea110c352bd12cb76e527eeb35c18',1,'spinftransistor::spin()']]],
  ['stroke_5fwidth',['stroke_width',['../classftransistor.html#a54583de79c6b0688a5567e2941b7eda4',1,'ftransistor']]]
];
