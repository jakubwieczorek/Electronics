var searchData=
[
  ['ftransistor',['ftransistor',['../classftransistor.html#aba44319511d62e7a95576886bc29850a',1,'ftransistor::ftransistor(unsigned short width, unsigned short line_color[], unsigned short interior_color[], unsigned short stroke_width, unsigned short local[], std::string name)'],['../classftransistor.html#a2edb7861c62a8299b266366cd085a353',1,'ftransistor::ftransistor()']]]
];
