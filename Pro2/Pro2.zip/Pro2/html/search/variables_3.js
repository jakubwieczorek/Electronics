var searchData=
[
  ['name',['name',['../classftransistor.html#a429e22a64222ccea1e58dffc89f9a8e6',1,'ftransistor']]]
];
