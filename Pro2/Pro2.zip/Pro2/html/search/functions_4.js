var searchData=
[
  ['operator_2b',['operator+',['../classDokument.html#af4b65967a289caaf08df8e2f60702e8d',1,'Dokument']]],
  ['operator_2d',['operator-',['../classDokument.html#a7973008af73e9f45d075d0e635e893d1',1,'Dokument']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classDokument.html#aeb8d20eca2b57bf64beeffe3f3c3b96c',1,'Dokument']]]
];
