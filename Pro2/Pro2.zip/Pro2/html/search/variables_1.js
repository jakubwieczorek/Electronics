var searchData=
[
  ['interior_5fcolor',['interior_color',['../classElement.html#ae2156b6b2526f81c81cf60c9d1a401e4',1,'Element']]],
  ['it_5fel',['it_el',['../classDokument.html#a092af9ec58bb3ae13edd57948cb96c05',1,'Dokument']]]
];
