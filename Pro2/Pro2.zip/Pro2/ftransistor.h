/**
* \brief class ftransistor inherit from Element
* \details   contain mathods witch allow generate svg code. It's phototransistor and this simbol is generated.
* \author    Jakub Wieczorek
*/

#ifndef FTRANSISTOR_H
#define FTRANSISTOR_H
#include"Element.h"

class ftransistor : public Element{

protected:
 ///the line color in rgb.
 unsigned short line_color[3];
 ///stroke width
 unsigned short stroke_width;
 ///name of particular ftransistor
 std::string name;
public:
 /// This is ID of this class. You can see field is static so every object of this type has the same ID.
 /// This is given by method of factory class.
 static unsigned int Type;
 ///constructor
 ftransistor(unsigned short width, unsigned short line_color[], unsigned short interior_color[], unsigned short stroke_width, unsigned short local[], std::string name);//konstruktor
 /**
 * \brief default constructor
 * \details
 * width = 100
 * all interior_color = 200
 * all local = 200
 * all line color = 100
 * name = ftransistor
 * stroke_width = 5
 */
 ftransistor();
 /// \brief setter to line_collor
 void set_line_color(unsigned short line_color[]){for(int i=0; i<3; i++)this->line_color[i]=line_color[i];}
 /// \brief setter to stroke_width
 void set_stroke_width(unsigned short stroke_width){this->stroke_width=stroke_width;}
 /// \brief setter to name
 void set_name(std::string name){this->name=name;}
 /**
 * \brief static function returning pointer to object of ftransistor type.
 * \details Given to object type Factory. It's explaining why this function is static.
 */
 static Element *  Createftransistor(){return new ftransistor();}

 /**
 * \brief show ID class of ftransistor. Returns ID.
 *
 */
 virtual unsigned int show_type(){return Type;}
 /**
 * \brief It's describing specification of object type ftransistor in terminal.
 * \details Come from class of Element
 */
 virtual void write();
 /** \brief Exports ftransistor to svg.
  * \param file to this file will be exported code svg describing ftrasistor.
  * \attention file should be opened and extension should be .svg. This method don't close file.
  */
 virtual void draw(std::ofstream &file);
 /** \brief Exports specification of ftransistor to file.
  * \param file to this file will be exported all information of ftransistor.
  * \attention file should be open, prefered extension is .txt. This method don't close file.
  */
 virtual void save(std::ofstream &file);
 /** \brief Imports specification of ftransistor from file.
  * \param file from this will be imported all information of ftransistor.
  * \attention file should be open. This method don't close file. */
 virtual void read(std::ifstream &file);
};
#endif
