/**
* \brief class lccdiode inherit from cdiode
* \details   contain mathods witch allow generate svg code. It's capacity diode with colored lines
* and this simbol is generated.
* \author Jakub Wieczorek
*/

#ifndef LCCDIODE_H
#define LCCDIODE_H
#include"cdiode.h"


class LCcdiode : public cdiode{

protected:
    /// \brief line color
    unsigned short line_color[3];

public:
    static unsigned Type;
    /**
    * \brief default constructor
    * \details
    * width = 100;
    * all interior_color = 100;
    * all line_color = 50
    * all local = 100;
    * spin = 0;
    */
    LCcdiode();
    /// \brief constructor
    LCcdiode(unsigned short width, unsigned short interior_color[], unsigned short local[], unsigned short spin, unsigned short line_color[]);//konstrukto

    /**
    * \brief static function returning pointer to object lccdiode.
    * \details Given to object type Factory. It's explaining why this function is static.
    */
    static Element *  CreateLCcdiode(){return new LCcdiode();}
    /// \brief setter line color
    void set_line_color(unsigned short line_color[]){for(int i=0; i<3; i++)this->line_color[i]=line_color[i];}
    /**
    * \brief show ID class lccdiode. Returns ID.
    *
    */
    virtual unsigned int show_type(){return Type;}
    /**
    * \brief It's describing specification of object type lccdiode in terminal.
    * \details Come from class of Element
    */
    virtual void write();
    /** \brief Exports lccdiode to svg.
     * \param file to this file will be exported code svg describing lccdiode.
     * \attention file should be opened and extension should be .svg. This method don't close file.
     */
    virtual void draw(std::ofstream &file);
    /** \brief Exports specification of lccdiode to file.
     * \param file to this file will be exported all information of lccdiode.
     * \attention file should be open, prefered extension is .txt. This method don't close file.
     */
    virtual void save(std::ofstream &file);
    /** \brief Imports specification of lccdiode from file.
     * \param file from this will be imported all information of lccdiode.
     * \attention file should be open. This method don't close file. */
    virtual void read(std::ifstream &file);
};
#endif

